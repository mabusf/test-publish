function subm (a, b) {
    console.log('hello')
    return a - b;
}